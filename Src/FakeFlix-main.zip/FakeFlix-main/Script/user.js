function btnPerfil() {

    window.location.replace ('index.html');
}

function btnPadd() {
    alert('Assine o GracifliX Pro para ter mais perfils!!!')
}

function btnPger() {
    alert('Você tem apenas um perfil !')
}